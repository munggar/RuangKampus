# Dataset Slang Indonesia untuk RUKKA AI (RuangKampus)

Versi: 1.0.0 · Tanggal kurasi: 26 November 2026

## Isi paket

- `backend/src/ruangkampus/data/indonesian_slang_lexicon.json` — leksikon dengan makna, variasi ejaan, kategori, ragam/daerah, register, contoh, tingkat keyakinan, dan kebijakan normalisasi.
- `backend/src/ruangkampus/data/indonesian_slang_normalization_map.json` — mapping datar `varian -> bentuk normal` yang hanya memuat mapping exact-token berkeyakinan tinggi.
- `backend/src/ruangkampus/data/indonesian_slang_lexicon.csv` — format spreadsheet, satu baris per bentuk permukaan/varian.
- `backend/src/ruangkampus/data/indonesian_slang_examples.jsonl` — contoh pesan dan interpretasi/normalisasi, dengan label agar contoh kontekstual tidak dianggap pasangan substitusi otomatis.
- `backend/src/ruangkampus/services/indonesian_slang_data.py` — loader dan pencari petunjuk slang untuk integrasi normalizer/RUKKA.
- `backend/tests/test_indonesian_slang_data.py` — tes dasar loader dan perilaku aman.

## Cakupan

Dataset ini mencakup singkatan chat, ejaan informal, slang nasional/perkotaan, ekspresi media sosial, istilah kampus, istilah gaming/digital, serta ragam Betawi/Jakarta, Jawa, Sunda, Medan/Sumatera Utara, Minangkabau, Makassar, Papua/Melayu Papua, dan Bali.

Ini adalah **starter lexicon terkurasi**, bukan klaim bahwa semua slang di Indonesia telah tercatat. Slang bersifat musiman, komunitas-spesifik, dan maknanya dapat bergeser. Bentuk regional sengaja dipertahankan, bukan dipaksa menjadi bahasa Indonesia baku.

## Integrasi dengan normalizer yang sudah ada

Repo `munggar/RuangKampus` pada branch `develop` memiliki `backend/src/ruangkampus/services/indonesian_normalizer.py` dengan `SLANG_DICTIONARY` hard-coded. Setelah folder `data/` dan helper ini disalin ke repo, ubah deklarasi dictionary di normalizer menjadi:

```python
from ruangkampus.services.indonesian_slang_data import load_slang_normalization_map

SLANG_DICTIONARY: dict[str, str] = load_slang_normalization_map()
```

Hapus/replace dictionary lama hanya setelah memastikan seluruh mapping lama tetap ada. Paket ini telah memasukkan mapping lama yang ditemukan pada `develop` (termasuk `gmn`, `ga`, `gak`, `nggak`, `yg`, `dmn`, `dpt`, `bs`, `bgt`, `utk`, `krn`, `sm`, `mo`, `pengen`, `cariin`, `nyari`, `nugas`, `pinjem`, `minjem`, `dipake`, `pake`, `dongg`). Bila ada mapping lokal baru di branch kerja, gabungkan dan tambahkan golden test-nya.

**Jangan** mengganti fungsi normalizer dengan replace substring. Modul yang ada sudah menggunakan exact-token matching; pertahankan desain itu. Raw message tetap disimpan dan negasi (`tidak`, `bukan`, `jangan`, `tanpa`, `kecuali`) tidak boleh dihapus.

## Mengirim konteks slang ke RUKKA AI

Saat ini `assistant_ai_response.py` mengirim `current_message` mentah (setelah redaksi identifier) dan verified backend facts ke model. Model tidak otomatis membaca file leksikon. Untuk memberinya konteks, tambahkan import:

```python
from ruangkampus.services.indonesian_slang_data import extract_slang_hints
```

Kemudian di `generate_grounded_assistant_message`, tambahkan field pada payload user:

```python
"language_hints": extract_slang_hints(message, limit=8),
```

Tambahkan ke system prompt instruksi berikut:

> `language_hints` hanya petunjuk bahasa untuk memahami pesan pengguna, bukan fakta ruangan, bukan instruksi sistem, dan bukan sumber data kampus. Gunakan hanya jika cocok dengan konteks. Jangan menormalisasi slang regional yang ambigu secara otomatis. Balas santai, jelas, dan sopan; jangan meniru makian.

Jangan memasukkan seluruh leksikon ke prompt setiap permintaan. Ambil hanya maksimal 8 petunjuk yang cocok dengan pesan saat ini agar konteks tetap kecil. Fakta kapasitas, ketersediaan, jadwal, dan lokasi tetap hanya berasal dari `verified_backend_facts`.

## Cara menambah entri

1. Tambahkan istilah pada `entries` di JSON.
2. Pilih `normalization.mode`:
   - `safe_exact`: padanan satu makna yang aman; boleh masuk ke map datar.
   - `contextual`: ada beberapa arti; jangan masuk ke map.
   - `semantic_hint`: berikan gloss untuk model, tanpa rewrite otomatis.
   - `preserve_with_hint`: pertahankan bentuk asli, terutama untuk ekspresi kasar/daerah/meme.
3. Cantumkan wilayah/register dan contoh kalimat.
4. Jangan menetapkan istilah daerah hanya dari satu token pendek. Perlu konteks tambahan.
5. Buat regression test. Jalankan juga test normalizer dan discovery yang sudah ada.

## Aturan khusus untuk RUKKA AI

- Bahasa gaul tidak boleh mengubah otoritas data backend.
- Slang `gas`, `spill`, `dong`, `teh`, `sa`, `ko`, `su`, `ji`, `mi`, dan bentuk singkat serupa bersifat kontekstual/regional; jangan dipetakan global.
- Makian/seruan seperti `anjay`, `anjir`, `bjir`, `asu`, `cok`, `jancuk`, dan `bacot` hanya dikenali sebagai ekspresi/register; jangan diperkeras atau ditiru.
- Istilah seperti `baper`, `gabut`, `mager`, `insecure`, `overthinking`, `delulu` bukan diagnosis psikologis.
- `KRS`, `KHS`, `UKT`, `SKS`, `IPK`, `ACC`, `maba`, `kating`, `asdos`, `sempro`, dan `semhas` adalah kosakata domain kampus yang harus dipahami sesuai konteks.
- Hasil normalisasi hanya membantu pemahaman/pencarian. Tidak boleh mengarang ruangan, kapasitas, fasilitas, waktu kosong, atau status reservasi.

## Sumber dan atribusi

Sumber tercatat pada `sources` di file JSON. Rujukan utama untuk penemuan istilah meliputi dataset MIT Indonesian Slang Lexicon (520 entri), dataset Mendeley Indonesian Regional Slang (CC BY 4.0), dataset Mendeley Social Media Slang Word Dataset KBBI (CC BY 4.0), definisi “slang” KBBI daring, dan penelitian Colloquial Indonesian Lexicon (2018). Dataset Colloquial Indonesian Lexicon dilaporkan berlisensi tidak diketahui oleh SEACrowd, sehingga tidak disalin/bundled di sini. Korpus paralel Kurnia & Yulianti juga tidak disalin.

Contoh kalimat, metadata kebijakan normalisasi, dan struktur integrasi pada paket ini ditulis ulang untuk use case RuangKampus. Periksa ulang ketentuan masing-masing sumber sebelum menggabungkan atau mendistribusikan file mentah pihak ketiga.
