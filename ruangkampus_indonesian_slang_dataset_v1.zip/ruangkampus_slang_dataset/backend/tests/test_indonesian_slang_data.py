from ruangkampus.services.indonesian_slang_data import (
    extract_slang_hints,
    load_slang_lexicon,
    load_slang_normalization_map,
)


def test_lexicon_schema_and_version():
    payload = load_slang_lexicon()
    assert payload["schema_version"] == "1.0.0"
    assert len(payload["entries"]) >= 100


def test_exact_normalization_map_contains_existing_core_forms():
    mapping = load_slang_normalization_map()
    assert mapping["gmn"] == "bagaimana"
    assert mapping["nggak"] == "tidak"
    assert mapping["nugas"] == "mengerjakan tugas"
    assert mapping["pake"] == "pakai"


def test_ambiguous_words_are_not_added_to_flat_map():
    mapping = load_slang_normalization_map()
    assert "gas" not in mapping
    assert "spill" not in mapping
    assert "teh" not in mapping
    assert "sa" not in mapping


def test_contextual_terms_can_be_retrieved_as_hints():
    hints = extract_slang_hints("Wkwk, gaskeun cari ruang; aku lagi mager.")
    words = {item["headword"] for item in hints}
    assert "wkwk" in words
    assert "gaskeun" in words
    assert "mager" in words


def test_single_short_regional_token_is_not_assumed_to_be_dialect():
    hints = extract_slang_hints("Sa mau cari ruangan.")
    assert "sa" not in {item["headword"] for item in hints}


def test_regional_hints_need_corroborating_terms():
    hints = extract_slang_hints("Sa tra jadi ke kampus.")
    words = {item["headword"] for item in hints}
    assert "sa" in words
    assert "tra" in words
