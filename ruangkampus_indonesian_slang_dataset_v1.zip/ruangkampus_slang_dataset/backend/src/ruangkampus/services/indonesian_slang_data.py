from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any

_DATA_DIR = Path(__file__).resolve().parents[1] / "data"
_LEXICON_PATH = _DATA_DIR / "indonesian_slang_lexicon.json"
_MAP_PATH = _DATA_DIR / "indonesian_slang_normalization_map.json"


@lru_cache(maxsize=1)
def load_slang_lexicon() -> dict[str, Any]:
    """Load the versioned lexicon once. Raw user messages are never written here."""
    with _LEXICON_PATH.open("r", encoding="utf-8") as file:
        payload = json.load(file)
    if payload.get("schema_version") != "1.0.0" or not isinstance(payload.get("entries"), list):
        raise ValueError("Unsupported Indonesian slang lexicon schema")
    return payload


@lru_cache(maxsize=1)
def load_slang_normalization_map() -> dict[str, str]:
    """Return high-certainty exact-token replacements only."""
    with _MAP_PATH.open("r", encoding="utf-8") as file:
        mapping = json.load(file)
    if not isinstance(mapping, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in mapping.items()):
        raise ValueError("Invalid Indonesian slang normalization map")
    return {key.casefold(): value for key, value in mapping.items()}


def extract_slang_hints(message: str, *, limit: int = 10) -> list[dict[str, str]]:
    """Find relevant glosses for the current RUKKA turn; phrase-boundary matching only.

    Regional short forms are returned only when at least two terms from the same
    regional variety occur in the same message, reducing false positives such as
    treating ordinary Indonesian 'sa', 'ko', 'su', 'teh', or 'dong' as dialect.
    """
    if not isinstance(message, str) or not message.strip() or limit < 1:
        return []
    text = message.casefold()
    hits: list[tuple[int, int, dict[str, str]]] = []
    for entry in load_slang_lexicon()["entries"]:
        matched_at = None
        matched_form = None
        for form in entry.get("surface_forms", []):
            pattern = rf"(?<![\w]){re.escape(form.casefold())}(?![\w])"
            match = re.search(pattern, text, flags=re.UNICODE)
            if match and (matched_at is None or match.start() < matched_at):
                matched_at, matched_form = match.start(), form
        if matched_at is not None:
            hits.append((matched_at, -len(matched_form or ""), {
                "surface_form": matched_form or entry["headword"],
                "headword": entry["headword"],
                "meaning": entry["meaning"],
                "region": entry["region"],
                "category": entry["category"],
                "register": entry["register"],
                "context_note": entry.get("context_note", ""),
            }))
    hits.sort(key=lambda item: (item[0], item[1]))

    # Require corroborating regional markers only for short regional particles/pronouns.
    regional_counts: dict[str, int] = {}
    for _, _, hit in hits:
        if hit["category"] == "ragam_daerah" and len(hit["surface_form"]) <= 4:
            regional_counts[hit["region"]] = regional_counts.get(hit["region"], 0) + 1
    output: list[dict[str, str]] = []
    seen: set[str] = set()
    for _, _, hit in hits:
        region = hit["region"]
        if (hit["category"] == "ragam_daerah" and len(hit["surface_form"]) <= 4
                and regional_counts.get(region, 0) < 2):
            continue
        key = hit["headword"]
        if key in seen:
            continue
        seen.add(key)
        output.append(hit)
        if len(output) >= limit:
            break
    return output
