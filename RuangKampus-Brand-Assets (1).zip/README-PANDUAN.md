# RuangKampus — Brand Asset Kit

Paket ini berisi aset yang diekstrak langsung dari gambar logo yang diberikan. Logo **tidak digambar ulang** dan teks/tagline tidak diketik ulang.

## Isi paket

```text
public/
├── brand/
│   ├── logo-primary.png                 # Logo utama transparan, lengkap dengan tagline
│   ├── logo-primary-white-bg.png        # Logo utama dengan latar putih
│   └── favicon/
│       ├── favicon.ico                  # Favicon multi-size
│       ├── favicon-16x16.png
│       ├── favicon-32x32.png
│       ├── favicon-48x48.png
│       ├── favicon-64x64.png
│       ├── favicon-128x128.png
│       ├── favicon-180x180.png
│       ├── favicon-192x192.png
│       ├── favicon-256x256.png
│       ├── favicon-512x512.png
│       ├── apple-touch-icon.png         # 180 × 180, latar putih
│       └── site.webmanifest
└── SOURCE-original-reference.jpg        # Salinan gambar sumber untuk referensi
```

## Aturan penggunaan identitas visual

1. **Logo utama website:** gunakan `public/brand/logo-primary.png` sebagai satu gambar utuh. File ini sudah mencakup simbol, tulisan “RuangKampus”, dan tagline “Find the Room. Book the Space.”
2. **Favicon:** gunakan file pada `public/brand/favicon/`. Favicon sengaja hanya menggunakan simbol, tanpa tulisan dan tagline agar tetap terbaca pada ukuran kecil.
3. Jangan mengetik ulang tulisan logo menggunakan font website. Jangan mengganti simbol dengan ikon library (Lucide, Font Awesome, Material Icons, dan sebagainya).
4. Jangan membuat ulang logo dengan AI, CSS, SVG tracing, vectorizer, atau generator logo. Jangan mengubah bentuk, proporsi, warna, sudut, jarak, tipografi, maupun tagline.
5. Jangan meregangkan gambar. Selalu pertahankan rasio aslinya dan gunakan `object-fit: contain`.
6. Jangan menerapkan CSS filter, recolor, mask, blend mode, opacity, outline, shadow, atau efek lain pada logo.
7. Karena logo menggunakan tulisan biru tua dan biru terang, letakkan pada area putih atau latar terang yang bersih. Untuk dark mode, pertahankan file logo asli di atas bidang putih/netral terang; **jangan membuat versi putih dengan mengubah warna logo**.
8. Jika logo perlu tampil di banyak tempat (header desktop, header mobile, halaman login, halaman pemuatan), gunakan file aset yang sama. Jangan membuat variasi logo baru.
9. Jika desain/mockup dibuat dengan AI, minta AI menyisakan area penempatan logo. Setelah itu, pasang file PNG asli sebagai image layer/elemen `<img>` melalui kode. Jangan meminta AI menggambar logo ke dalam hasil render, karena tulisan dan geometri dapat berubah.
10. Jika file tidak tampil, periksa path dan case-sensitive filename. Jangan menggantinya dengan logo hasil generasi.

## Pemasangan HTML

Letakkan folder `public/brand` pada folder `public` proyek. Tambahkan tag berikut di bagian `<head>`:

```html
<link rel="icon" href="/brand/favicon/favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="/brand/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/brand/favicon/favicon-16x16.png">
<link rel="apple-touch-icon" href="/brand/favicon/apple-touch-icon.png">
<link rel="manifest" href="/brand/favicon/site.webmanifest">
<meta name="theme-color" content="#ffffff">
```

Pasang logo utama di header:

```html
<a class="brand" href="/" aria-label="RuangKampus beranda">
  <img
    src="/brand/logo-primary.png"
    alt="RuangKampus — Find the Room. Book the Space."
    class="brand__logo"
  >
</a>
```

CSS yang disarankan:

```css
.brand {
  display: inline-flex;
  align-items: center;
  min-width: 0;
  line-height: 0;
}

.brand__logo {
  display: block;
  width: clamp(190px, 24vw, 320px);
  height: auto;
  max-width: 100%;
  object-fit: contain;
}
```

## Pemasangan React / Next.js

Komponen React:

```jsx
export function BrandLogo() {
  return (
    <a className="brand" href="/" aria-label="RuangKampus beranda">
      <img
        src="/brand/logo-primary.png"
        alt="RuangKampus — Find the Room. Book the Space."
        className="brand__logo"
      />
    </a>
  );
}
```

Untuk Next.js App Router, tag favicon dapat ditambahkan di `app/layout.tsx`:

```tsx
export const metadata = {
  title: "RuangKampus",
  description: "Find the Room. Book the Space.",
  icons: {
    icon: [
      { url: "/brand/favicon/favicon.ico" },
      { url: "/brand/favicon/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/brand/favicon/favicon-16x16.png", sizes: "16x16", type: "image/png" }
    ],
    apple: "/brand/favicon/apple-touch-icon.png",
    other: [
      { rel: "manifest", url: "/brand/favicon/site.webmanifest" }
    ]
  }
};
```

Sesuaikan integrasi dengan struktur proyek yang sudah ada. Jangan menghapus konfigurasi lain yang masih digunakan.

## Catatan teknis

- `logo-primary.png`: PNG RGBA transparan, 1430 × 332 piksel.
- `logo-primary-white-bg.png`: PNG dengan latar putih, 1430 × 332 piksel.
- Semua file favicon dibuat dari simbol pada gambar sumber yang sama; tidak dibuat ulang sebagai gambar baru.
- `SOURCE-original-reference.jpg` disertakan agar implementer dapat membandingkan hasil dengan gambar referensi.
